import { useState, useMemo, useEffect } from 'react';
import { Cloud, Droplets, Wind, MapPin, AlertTriangle, Activity, Waves, Mountain, Car } from 'lucide-react';
import { PhilippinesMap } from '@/components/PhilippinesMap';
import { WeatherCard } from '@/components/WeatherCard';
import { HazardAlertCard, HazardZoneCard } from '@/components/HazardAlert';
import { ForecastCard } from '@/components/ForecastCard';
import { MapControls } from '@/components/MapControls';
import { MapLegend } from '@/components/MapLegend';
import { Header } from '@/components/Header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import type { HazardType, SeverityLevel, HazardZone } from '@/types';
import { philippinesHazardZones, weatherAlerts, majorCities, forecastData, trafficData } from '@/data/hazardData';
import './App.css';

function App() {
  // State for map controls
  const [selectedHazardType, setSelectedHazardType] = useState<HazardType>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<SeverityLevel>('all');
  const [showRivers, setShowRivers] = useState(true);
  const [showFaultLines, setShowFaultLines] = useState(true);
  const [showCities, setShowCities] = useState(true);
  const [showTraffic, setShowTraffic] = useState(true);
  const [selectedZone, setSelectedZone] = useState<HazardZone | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Calculate hazard counts
  const hazardCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    philippinesHazardZones.forEach((zone) => {
      counts[zone.type] = (counts[zone.type] || 0) + 1;
    });
    return counts;
  }, []);

  // Filter hazard zones
  const filteredZones = useMemo(() => {
    return philippinesHazardZones.filter((zone) => {
      const typeMatch = selectedHazardType === 'all' || zone.type === selectedHazardType;
      const severityMatch = selectedSeverity === 'all' || zone.severity === selectedSeverity;
      return typeMatch && severityMatch;
    });
  }, [selectedHazardType, selectedSeverity]);

  // Get severity color
  const getSeverityColor = (severity: string) => {
    const colors: Record<string, string> = {
      low: 'text-green-400',
      moderate: 'text-yellow-400',
      high: 'text-orange-400',
      severe: 'text-red-400',
      extreme: 'text-purple-400',
    };
    return colors[severity] || 'text-gray-400';
  };

  // Get hazard icon
  const getHazardIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      flood: <Droplets className="w-5 h-5 text-blue-400" />,
      earthquake: <Mountain className="w-5 h-5 text-red-400" />,
      storm: <Wind className="w-5 h-5 text-purple-400" />,
      landslide: <Activity className="w-5 h-5 text-amber-400" />,
      tsunami: <Waves className="w-5 h-5 text-cyan-400" />,
    };
    return icons[type] || <AlertTriangle className="w-5 h-5" />;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header activeAlerts={weatherAlerts.length} />

      {/* Main Content */}
      <main className="pt-14 h-screen">
        <div className="h-full flex flex-col lg:flex-row">
          {/* Map Section - Takes up most space */}
          <div className="flex-1 relative min-h-[50vh] lg:min-h-0">
            <PhilippinesMap
              selectedHazardType={selectedHazardType}
              selectedSeverity={selectedSeverity}
              showRivers={showRivers}
              showFaultLines={showFaultLines}
              showCities={showCities}
              showTraffic={showTraffic}
              onZoneClick={setSelectedZone}
            />

            {/* Map Legend */}
            <MapLegend showTraffic={showTraffic} />

            {/* Map Overlay - Current Time */}
            <div className="absolute top-4 left-4 z-[400] glass rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <Cloud className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">
                  {currentTime.toLocaleString('en-PH', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            </div>

            {/* Map Overlay - Quick Stats */}
            <div className="absolute bottom-4 left-4 z-[400] glass rounded-lg p-3 hidden md:block">
              <div className="flex flex-col gap-2">
                <div className="flex gap-4 text-xs">
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-blue-400" />
                    <span>{hazardCounts.flood || 0} Flood Zones</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-400" />
                    <span>{hazardCounts.earthquake || 0} Fault Lines</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                    <span>{hazardCounts.storm || 0} Storm Areas</span>
                  </div>
                </div>
                {showTraffic && (
                  <div className="flex gap-4 text-xs border-t border-border/50 pt-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Car className="w-3 h-3 text-green-400" />
                      <span className="text-green-400">{trafficData.filter(t => t.congestion === 'low').length} Flowing</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Car className="w-3 h-3 text-yellow-400" />
                      <span className="text-yellow-400">{trafficData.filter(t => t.congestion === 'moderate').length} Moderate</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Car className="w-3 h-3 text-orange-400" />
                      <span className="text-orange-400">{trafficData.filter(t => t.congestion === 'high').length} Heavy</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Car className="w-3 h-3 text-red-400" />
                      <span className="text-red-400">{trafficData.filter(t => t.congestion === 'severe').length} Severe</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-full lg:w-96 bg-card/50 backdrop-blur border-l border-border">
            <Tabs defaultValue="weather" className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-3 m-4 mb-0">
                <TabsTrigger value="weather">Weather</TabsTrigger>
                <TabsTrigger value="hazards">Hazards</TabsTrigger>
                <TabsTrigger value="layers">Layers</TabsTrigger>
              </TabsList>

              <ScrollArea className="flex-1 p-4">
                {/* Weather Tab */}
                <TabsContent value="weather" className="mt-0 space-y-4">
                  {/* Current Weather - Manila */}
                  <WeatherCard weather={majorCities[0].weather} />

                  {/* Weather Alerts */}
                  {weatherAlerts.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-destructive" />
                        Active Alerts ({weatherAlerts.length})
                      </h3>
                      {weatherAlerts.map((alert) => (
                        <HazardAlertCard key={alert.id} alert={alert} />
                      ))}
                    </div>
                  )}

                  <Separator />

                  {/* 7-Day Forecast */}
                  <ForecastCard forecast={forecastData} />

                  {/* Other Cities */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Other Major Cities</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {majorCities.slice(1).map((city) => (
                        <WeatherCard key={city.name} weather={city.weather} compact />
                      ))}
                    </div>
                  </div>
                </TabsContent>

                {/* Hazards Tab */}
                <TabsContent value="hazards" className="mt-0 space-y-4">
                  {/* Hazard Summary */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="glass rounded-lg p-3 text-center">
                      <Droplets className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                      <p className="text-2xl font-bold">{hazardCounts.flood || 0}</p>
                      <p className="text-xs text-muted-foreground">Flood Zones</p>
                    </div>
                    <div className="glass rounded-lg p-3 text-center">
                      <Mountain className="w-6 h-6 text-red-400 mx-auto mb-1" />
                      <p className="text-2xl font-bold">{hazardCounts.earthquake || 0}</p>
                      <p className="text-xs text-muted-foreground">Fault Lines</p>
                    </div>
                    <div className="glass rounded-lg p-3 text-center">
                      <Wind className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                      <p className="text-2xl font-bold">{hazardCounts.storm || 0}</p>
                      <p className="text-xs text-muted-foreground">Storm Areas</p>
                    </div>
                    <div className="glass rounded-lg p-3 text-center">
                      <Activity className="w-6 h-6 text-amber-400 mx-auto mb-1" />
                      <p className="text-2xl font-bold">{hazardCounts.landslide || 0}</p>
                      <p className="text-xs text-muted-foreground">Landslide Risk</p>
                    </div>
                  </div>

                  <Separator />

                  {/* Filtered Hazard Zones */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium">Hazard Zones</h3>
                      <Badge variant="secondary">{filteredZones.length}</Badge>
                    </div>
                    <div className="space-y-2">
                      {filteredZones.map((zone) => (
                        <HazardZoneCard
                          key={zone.id}
                          zone={zone}
                          onClick={() => setSelectedZone(zone)}
                        />
                      ))}
                    </div>
                  </div>
                </TabsContent>

                {/* Layers Tab */}
                <TabsContent value="layers" className="mt-0">
                  <MapControls
                    selectedHazardType={selectedHazardType}
                    setSelectedHazardType={setSelectedHazardType}
                    selectedSeverity={selectedSeverity}
                    setSelectedSeverity={setSelectedSeverity}
                    showRivers={showRivers}
                    setShowRivers={setShowRivers}
                    showFaultLines={showFaultLines}
                    setShowFaultLines={setShowFaultLines}
                    showCities={showCities}
                    setShowCities={setShowCities}
                    showTraffic={showTraffic}
                    setShowTraffic={setShowTraffic}
                    hazardCounts={hazardCounts}
                  />
                </TabsContent>
              </ScrollArea>
            </Tabs>
          </div>
        </div>
      </main>

      {/* Zone Detail Dialog */}
      <Dialog open={!!selectedZone} onOpenChange={() => setSelectedZone(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedZone && getHazardIcon(selectedZone.type)}
              {selectedZone?.name}
            </DialogTitle>
          </DialogHeader>
          {selectedZone && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={`${getSeverityColor(selectedZone.severity)} border-current`}
                >
                  {selectedZone.severity.toUpperCase()}
                </Badge>
                <Badge variant="secondary" className="capitalize">
                  {selectedZone.type}
                </Badge>
              </div>

              <p className="text-muted-foreground">{selectedZone.description}</p>

              <div>
                <h4 className="text-sm font-medium mb-2">Affected Areas</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedZone.affectedAreas.map((area) => (
                    <Badge key={area} variant="secondary">
                      <MapPin className="w-3 h-3 mr-1" />
                      {area}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-destructive/10 rounded-lg border border-destructive/20">
                <h4 className="text-sm font-medium text-destructive mb-1">
                  <AlertTriangle className="w-4 h-4 inline mr-1" />
                  Advisory
                </h4>
                <p className="text-sm text-destructive/80">{selectedZone.advisory}</p>
              </div>

              <div className="text-xs text-muted-foreground">
                Last updated: {new Date(selectedZone.lastUpdated).toLocaleString('en-PH')}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
