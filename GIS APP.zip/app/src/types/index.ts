export interface WeatherData {
  location: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  condition: string;
  icon: string;
  description: string;
  pressure: number;
  visibility: number;
  uvIndex: number;
  coord: {
    lat: number;
    lon: number;
  };
}

export interface ForecastData {
  date: string;
  tempHigh: number;
  tempLow: number;
  condition: string;
  icon: string;
  precipitation: number;
  humidity: number;
}

export interface HazardZone {
  id: string;
  name: string;
  type: 'flood' | 'earthquake' | 'storm' | 'landslide' | 'tsunami';
  severity: 'low' | 'moderate' | 'high' | 'severe' | 'extreme';
  coordinates: [number, number][];
  center: [number, number];
  description: string;
  affectedAreas: string[];
  lastUpdated: string;
  advisory: string;
}

export interface WeatherAlert {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'moderate' | 'high' | 'severe' | 'extreme';
  type: string;
  areas: string[];
  effective: string;
  expires: string;
  instruction: string;
}

export interface CityWeather {
  name: string;
  coord: [number, number];
  weather: WeatherData;
}

export interface GISLayer {
  id: string;
  name: string;
  type: 'rainfall' | 'landuse' | 'flood' | 'elevation' | 'drainage';
  visible: boolean;
  opacity: number;
  data?: unknown;
}

export type HazardType = 'all' | 'flood' | 'earthquake' | 'storm' | 'landslide' | 'tsunami';
export type SeverityLevel = 'all' | 'low' | 'moderate' | 'high' | 'severe' | 'extreme';

export interface TrafficSegment {
  id: string;
  name: string;
  path: [number, number][];
  congestion: 'low' | 'moderate' | 'high' | 'severe';
  speed: number;
  lastUpdated: string;
}
