import { Cloud, Menu, MapPin, AlertTriangle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface HeaderProps {
  activeAlerts: number;
}

export function Header({ activeAlerts }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center justify-between h-14 px-4">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <Cloud className="w-6 h-6 text-primary" />
          <div className="flex flex-col">
            <span className="font-bold text-sm leading-tight">PH Weather & Hazards</span>
            <span className="text-[10px] text-muted-foreground">Real-time Monitoring</span>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Alerts Badge */}
          {activeAlerts > 0 && (
            <Badge variant="destructive" className="hidden sm:flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              {activeAlerts} Active
            </Badge>
          )}

          {/* About Dialog */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Info className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Cloud className="w-5 h-5 text-primary" />
                  Philippines Weather & Hazard Monitor
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <p>
                  A comprehensive weather and hazard monitoring application for the Philippines,
                  integrating real-time weather data with GIS-based hazard zone visualization.
                </p>
                
                <div>
                  <h4 className="font-medium mb-2">Data Sources</h4>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• PAGASA - Philippine Atmospheric, Geophysical and Astronomical Services</li>
                    <li>• PHIVOLCS - Philippine Institute of Volcanology and Seismology</li>
                    <li>• Project NOAH - Nationwide Operational Assessment of Hazards</li>
                    <li>• HazardHunterPH - GeoRisk Philippines</li>
                    <li>• OpenStreetMap - Base map data</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Hazard Types</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-400" />
                      <span className="text-muted-foreground">Floods</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-red-400" />
                      <span className="text-muted-foreground">Earthquakes</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-purple-400" />
                      <span className="text-muted-foreground">Storms</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      <span className="text-muted-foreground">Landslides</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      <span className="text-muted-foreground">Tsunami</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <p className="text-xs text-muted-foreground">
                  This application is for informational purposes only. Always follow official
                  advisories from PAGASA, PHIVOLCS, and local disaster risk management offices.
                </p>
              </div>
            </DialogContent>
          </Dialog>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 md:hidden">
                <Menu className="w-4 h-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Quick Navigation
                </SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-4">
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Major Cities Weather</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {['Manila', 'Quezon City', 'Cebu', 'Davao', 'Baguio', 'Iloilo'].map((city) => (
                      <Button key={city} variant="outline" size="sm" className="justify-start">
                        <MapPin className="w-3 h-3 mr-2" />
                        {city}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
