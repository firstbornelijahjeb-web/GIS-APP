import { useState } from 'react';
import { ChevronDown, ChevronUp, Droplets, Mountain, Wind, Waves, Activity, Car, Navigation } from 'lucide-react';

interface MapLegendProps {
  showTraffic: boolean;
}

const hazardItems = [
  { icon: <Droplets className="w-4 h-4" />, label: 'Flood Zone', color: '#3b82f6', bgColor: 'bg-blue-500' },
  { icon: <Mountain className="w-4 h-4" />, label: 'Earthquake Fault', color: '#ef4444', bgColor: 'bg-red-500' },
  { icon: <Wind className="w-4 h-4" />, label: 'Storm Corridor', color: '#a855f7', bgColor: 'bg-purple-500' },
  { icon: <Activity className="w-4 h-4" />, label: 'Landslide Risk', color: '#f59e0b', bgColor: 'bg-amber-500' },
  { icon: <Waves className="w-4 h-4" />, label: 'Tsunami Zone', color: '#06b6d4', bgColor: 'bg-cyan-500' },
];

const severityItems = [
  { label: 'Low Risk', color: '#22c55e', bgColor: 'bg-green-500' },
  { label: 'Moderate', color: '#eab308', bgColor: 'bg-yellow-500' },
  { label: 'High Risk', color: '#f97316', bgColor: 'bg-orange-500' },
  { label: 'Severe', color: '#ef4444', bgColor: 'bg-red-500' },
  { label: 'Extreme', color: '#a855f7', bgColor: 'bg-purple-500' },
];

const trafficItems = [
  { label: 'Flowing', color: '#22c55e', bgColor: 'bg-green-500', speed: '> 40 km/h' },
  { label: 'Moderate', color: '#eab308', bgColor: 'bg-yellow-500', speed: '25-40 km/h' },
  { label: 'Heavy', color: '#f97316', bgColor: 'bg-orange-500', speed: '15-25 km/h' },
  { label: 'Severe', color: '#ef4444', bgColor: 'bg-red-500', speed: '< 15 km/h' },
];

export function MapLegend({ showTraffic }: MapLegendProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState<'hazards' | 'traffic'>('hazards');

  return (
    <div className="absolute top-4 right-16 z-[400] max-w-[220px]">
      <div className="glass rounded-lg overflow-hidden shadow-lg">
        {/* Header */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-primary/20 to-primary/5 hover:from-primary/30 hover:to-primary/10 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Navigation className="w-4 h-4 text-primary" />
            <span className="font-semibold text-sm">Map Legend</span>
          </div>
          {isExpanded ? (
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          )}
        </button>

        {/* Content */}
        {isExpanded && (
          <div className="p-3">
            {/* Tabs */}
            {showTraffic && (
              <div className="flex gap-1 mb-3 p-1 bg-secondary/50 rounded-lg">
                <button
                  onClick={() => setActiveTab('hazards')}
                  className={`flex-1 px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeTab === 'hazards'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Hazards
                </button>
                <button
                  onClick={() => setActiveTab('traffic')}
                  className={`flex-1 px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeTab === 'traffic'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Car className="w-3 h-3 inline mr-1" />
                  Traffic
                </button>
              </div>
            )}

            {/* Hazard Legend */}
            {activeTab === 'hazards' && (
              <div className="space-y-3">
                {/* Hazard Types */}
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2 font-medium">
                    Hazard Types
                  </p>
                  <div className="space-y-1.5">
                    {hazardItems.map((item) => (
                      <div key={item.label} className="flex items-center gap-2">
                        <div 
                          className={`w-5 h-5 rounded-md ${item.bgColor} bg-opacity-30 flex items-center justify-center`}
                          style={{ color: item.color }}
                        >
                          {item.icon}
                        </div>
                        <span className="text-xs">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Severity Levels */}
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2 font-medium">
                    Severity Levels
                  </p>
                  <div className="space-y-1.5">
                    {severityItems.map((item) => (
                      <div key={item.label} className="flex items-center gap-2">
                        <div 
                          className="w-4 h-4 rounded-full border-2 border-white/20"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-xs">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Traffic Legend */}
            {activeTab === 'traffic' && showTraffic && (
              <div className="space-y-3">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2 font-medium">
                    Traffic Conditions
                  </p>
                  <div className="space-y-2">
                    {trafficItems.map((item) => (
                      <div key={item.label} className="flex items-center gap-2">
                        <div className="flex flex-col items-center">
                          <div 
                            className="w-6 h-1.5 rounded-full"
                            style={{ 
                              backgroundColor: item.color,
                              height: item.label === 'Severe' ? '6px' : item.label === 'Heavy' ? '5px' : item.label === 'Moderate' ? '4px' : '3px'
                            }}
                          />
                        </div>
                        <div className="flex-1">
                          <span className="text-xs block">{item.label}</span>
                          <span className="text-[10px] text-muted-foreground">{item.speed}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-border">
                  <p className="text-[10px] text-muted-foreground">
                    <Car className="w-3 h-3 inline mr-1" />
                    Live data from MMDA & DPWH
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
