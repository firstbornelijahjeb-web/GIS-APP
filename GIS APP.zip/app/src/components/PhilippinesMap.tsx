import { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Polygon, Circle, Polyline, Marker, Popup, LayersControl, LayerGroup } from 'react-leaflet';
import { Icon } from 'leaflet';
import type { HazardZone, HazardType, SeverityLevel } from '@/types';
import { philippinesHazardZones, philippinesBounds, riverSystems, faultLines, majorCities, trafficData } from '@/data/hazardData';

interface PhilippinesMapProps {
  selectedHazardType: HazardType;
  selectedSeverity: SeverityLevel;
  showRivers: boolean;
  showFaultLines: boolean;
  showCities: boolean;
  showTraffic: boolean;
  onZoneClick?: (zone: HazardZone) => void;
}

const severityColors = {
  low: '#22c55e',
  moderate: '#eab308',
  high: '#f97316',
  severe: '#ef4444',
  extreme: '#a855f7',
};

const severityFillOpacity = {
  low: 0.2,
  moderate: 0.3,
  high: 0.4,
  severe: 0.5,
  extreme: 0.6,
};

const trafficColors = {
  low: '#22c55e',
  moderate: '#eab308',
  high: '#f97316',
  severe: '#ef4444',
};

const trafficWeights = {
  low: 4,
  moderate: 5,
  high: 6,
  severe: 8,
};

const hazardIcons = {
  flood: '💧',
  earthquake: '🏔️',
  storm: '🌪️',
  landslide: '⛰️',
  tsunami: '🌊',
};

// Custom marker icons
const createCustomIcon = (emoji: string) => {
  return new Icon({
    iconUrl: `data:image/svg+xml,${encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
        <circle cx="15" cy="15" r="14" fill="rgba(0,0,0,0.7)" stroke="white" stroke-width="2"/>
        <text x="15" y="20" font-size="14" text-anchor="middle">${emoji}</text>
      </svg>`
    )}`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
    popupAnchor: [0, -15],
  });
};

export function PhilippinesMap({
  selectedHazardType,
  selectedSeverity,
  showRivers,
  showFaultLines,
  showCities,
  showTraffic,
  onZoneClick,
}: PhilippinesMapProps) {
  const [map, setMap] = useState<L.Map | null>(null);

  // Filter hazard zones based on selection
  const filteredZones = useMemo(() => {
    return philippinesHazardZones.filter((zone) => {
      const typeMatch = selectedHazardType === 'all' || zone.type === selectedHazardType;
      const severityMatch = selectedSeverity === 'all' || zone.severity === selectedSeverity;
      return typeMatch && severityMatch;
    });
  }, [selectedHazardType, selectedSeverity]);

  // Center of Philippines
  const center: [number, number] = [12.8797, 121.7740];

  useEffect(() => {
    if (map) {
      map.invalidateSize();
    }
  }, [map]);

  return (
    <MapContainer
      center={center}
      zoom={6}
      scrollWheelZoom={true}
      style={{ height: '100%', width: '100%', background: '#0f172a' }}
      ref={setMap}
      minZoom={5}
      maxZoom={12}
    >
      <LayersControl position="topright">
        {/* Base Layers */}
        <LayersControl.BaseLayer checked name="Dark Mode">
          <TileLayer
            attribution='&copy; <a href="https://carto.com/">CARTO</a>'
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          />
        </LayersControl.BaseLayer>
        <LayersControl.BaseLayer name="Satellite">
          <TileLayer
            attribution='&copy; <a href="https://esri.com">Esri</a>'
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
          />
        </LayersControl.BaseLayer>
        <LayersControl.BaseLayer name="OpenStreetMap">
          <TileLayer
            attribution='&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
        </LayersControl.BaseLayer>

        {/* Traffic Layer */}
        {showTraffic && (
          <LayersControl.Overlay checked name="Live Traffic">
            <LayerGroup>
              {trafficData.map((segment) => (
                <Polyline
                  key={segment.id}
                  positions={segment.path}
                  pathOptions={{
                    color: trafficColors[segment.congestion],
                    weight: trafficWeights[segment.congestion],
                    opacity: 0.9,
                    lineCap: 'round',
                    lineJoin: 'round',
                  }}
                >
                  <Popup>
                    <div className="p-3 min-w-[200px]">
                      <div className="flex items-center gap-2 mb-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: trafficColors[segment.congestion] }}
                        />
                        <h4 className="font-bold text-sm">{segment.name}</h4>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Congestion:</span>
                          <span 
                            className="font-medium capitalize"
                            style={{ color: trafficColors[segment.congestion] }}
                          >
                            {segment.congestion}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Speed:</span>
                          <span>{segment.speed} km/h</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Updated:</span>
                          <span className="text-xs">
                            {new Date(segment.lastUpdated).toLocaleTimeString('en-PH', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Popup>
                </Polyline>
              ))}
            </LayerGroup>
          </LayersControl.Overlay>
        )}

        {/* Hazard Zones Layer */}
        <LayersControl.Overlay checked name="Hazard Zones">
          <LayerGroup>
            {filteredZones.map((zone) => (
              <Polygon
                key={zone.id}
                positions={zone.coordinates}
                pathOptions={{
                  fillColor: severityColors[zone.severity],
                  fillOpacity: severityFillOpacity[zone.severity],
                  color: severityColors[zone.severity],
                  weight: 2,
                  dashArray: zone.type === 'earthquake' ? '5, 10' : undefined,
                }}
                eventHandlers={{
                  click: () => onZoneClick?.(zone),
                }}
              >
                <Popup>
                  <div className="p-2 min-w-[250px]">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">{hazardIcons[zone.type]}</span>
                      <h3 className="font-bold text-lg">{zone.name}</h3>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Type:</span>
                        <span className="capitalize font-medium">{zone.type}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Severity:</span>
                        <span
                          className="px-2 py-0.5 rounded text-xs font-medium capitalize"
                          style={{
                            backgroundColor: severityColors[zone.severity] + '30',
                            color: severityColors[zone.severity],
                          }}
                        >
                          {zone.severity}
                        </span>
                      </div>
                      <p className="text-muted-foreground mt-2">{zone.description}</p>
                      <div className="mt-2">
                        <span className="text-muted-foreground">Affected Areas:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {zone.affectedAreas.map((area) => (
                            <span
                              key={area}
                              className="px-2 py-0.5 bg-secondary rounded text-xs"
                            >
                              {area}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="mt-2 p-2 bg-destructive/10 rounded border border-destructive/20">
                        <span className="text-destructive font-medium">Advisory:</span>
                        <p className="text-xs mt-1">{zone.advisory}</p>
                      </div>
                    </div>
                  </div>
                </Popup>
              </Polygon>
            ))}
          </LayerGroup>
        </LayersControl.Overlay>

        {/* Hazard Markers */}
        <LayersControl.Overlay checked name="Hazard Centers">
          <LayerGroup>
            {filteredZones.map((zone) => (
              <Marker
                key={`marker-${zone.id}`}
                position={zone.center}
                icon={createCustomIcon(hazardIcons[zone.type])}
                eventHandlers={{
                  click: () => onZoneClick?.(zone),
                }}
              >
                <Popup>
                  <div className="p-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{hazardIcons[zone.type]}</span>
                      <span className="font-bold">{zone.name}</span>
                    </div>
                    <span
                      className="inline-block mt-1 px-2 py-0.5 rounded text-xs capitalize"
                      style={{
                        backgroundColor: severityColors[zone.severity] + '30',
                        color: severityColors[zone.severity],
                      }}
                    >
                      {zone.severity} {zone.type}
                    </span>
                  </div>
                </Popup>
              </Marker>
            ))}
          </LayerGroup>
        </LayersControl.Overlay>

        {/* River Systems */}
        {showRivers && (
          <LayersControl.Overlay checked name="River Systems">
            <LayerGroup>
              {riverSystems.map((river) => (
                <Polyline
                  key={river.name}
                  positions={river.path}
                  pathOptions={{
                    color: '#3b82f6',
                    weight: 3,
                    opacity: 0.7,
                  }}
                >
                  <Popup>
                    <div className="p-2">
                      <span className="font-medium">{river.name}</span>
                    </div>
                  </Popup>
                </Polyline>
              ))}
            </LayerGroup>
          </LayersControl.Overlay>
        )}

        {/* Fault Lines */}
        {showFaultLines && (
          <LayersControl.Overlay checked name="Fault Lines">
            <LayerGroup>
              {faultLines.map((fault) => (
                <Polyline
                  key={fault.name}
                  positions={fault.path}
                  pathOptions={{
                    color: '#ef4444',
                    weight: 3,
                    opacity: 0.8,
                    dashArray: '10, 10',
                  }}
                >
                  <Popup>
                    <div className="p-2">
                      <span className="font-medium text-destructive">{fault.name}</span>
                      <p className="text-xs text-muted-foreground mt-1">
                        Active geological fault line
                      </p>
                    </div>
                  </Popup>
                </Polyline>
              ))}
            </LayerGroup>
          </LayersControl.Overlay>
        )}

        {/* Major Cities */}
        {showCities && (
          <LayersControl.Overlay checked name="Major Cities">
            <LayerGroup>
              {majorCities.map((city) => (
                <Circle
                  key={city.name}
                  center={city.coord}
                  radius={8000}
                  pathOptions={{
                    fillColor: '#0ea5e9',
                    fillOpacity: 0.3,
                    color: '#0ea5e9',
                    weight: 2,
                  }}
                >
                  <Popup>
                    <div className="p-2 min-w-[200px]">
                      <h4 className="font-bold text-lg">{city.name}</h4>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Temperature:</span>
                          <span>{city.weather.temperature}°C</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Condition:</span>
                          <span>{city.weather.condition}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Humidity:</span>
                          <span>{city.weather.humidity}%</span>
                        </div>
                      </div>
                    </div>
                  </Popup>
                </Circle>
              ))}
            </LayerGroup>
          </LayersControl.Overlay>
        )}

        {/* Philippines Boundary */}
        <LayersControl.Overlay name="Philippines Boundary">
          <LayerGroup>
            <Polygon
              positions={philippinesBounds}
              pathOptions={{
                fillColor: 'transparent',
                color: '#64748b',
                weight: 2,
                dashArray: '5, 5',
              }}
            />
          </LayerGroup>
        </LayersControl.Overlay>
      </LayersControl>
    </MapContainer>
  );
}
