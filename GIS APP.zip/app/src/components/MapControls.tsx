import { Filter, Layers, Droplets, Mountain, Wind, Waves, AlertTriangle, MapPin, Route, Activity, Car } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { HazardType, SeverityLevel } from '@/types';

interface MapControlsProps {
  selectedHazardType: HazardType;
  setSelectedHazardType: (type: HazardType) => void;
  selectedSeverity: SeverityLevel;
  setSelectedSeverity: (severity: SeverityLevel) => void;
  showRivers: boolean;
  setShowRivers: (show: boolean) => void;
  showFaultLines: boolean;
  setShowFaultLines: (show: boolean) => void;
  showCities: boolean;
  setShowCities: (show: boolean) => void;
  showTraffic: boolean;
  setShowTraffic: (show: boolean) => void;
  hazardCounts: Record<string, number>;
}

const hazardTypes: { value: HazardType; label: string; icon: React.ReactNode; color: string }[] = [
  { value: 'all', label: 'All Hazards', icon: <AlertTriangle className="w-4 h-4" />, color: 'text-gray-400' },
  { value: 'flood', label: 'Floods', icon: <Droplets className="w-4 h-4" />, color: 'text-blue-400' },
  { value: 'earthquake', label: 'Earthquakes', icon: <Mountain className="w-4 h-4" />, color: 'text-red-400' },
  { value: 'storm', label: 'Storms', icon: <Wind className="w-4 h-4" />, color: 'text-purple-400' },
  { value: 'landslide', label: 'Landslides', icon: <Mountain className="w-4 h-4" />, color: 'text-amber-400' },
  { value: 'tsunami', label: 'Tsunami', icon: <Waves className="w-4 h-4" />, color: 'text-cyan-400' },
];

const severityLevels: { value: SeverityLevel; label: string; color: string }[] = [
  { value: 'all', label: 'All Levels', color: 'text-gray-400' },
  { value: 'low', label: 'Low', color: 'text-green-400' },
  { value: 'moderate', label: 'Moderate', color: 'text-yellow-400' },
  { value: 'high', label: 'High', color: 'text-orange-400' },
  { value: 'severe', label: 'Severe', color: 'text-red-400' },
  { value: 'extreme', label: 'Extreme', color: 'text-purple-400' },
];

export function MapControls({
  selectedHazardType,
  setSelectedHazardType,
  selectedSeverity,
  setSelectedSeverity,
  showRivers,
  setShowRivers,
  showFaultLines,
  setShowFaultLines,
  showCities,
  setShowCities,
  showTraffic,
  setShowTraffic,
  hazardCounts,
}: MapControlsProps) {
  return (
    <div className="space-y-4">
      {/* Hazard Filter */}
      <Card className="border-0 bg-card/50 backdrop-blur">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Hazard Filter
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Hazard Type Select */}
          <div className="space-y-2">
            <Label className="text-xs">Hazard Type</Label>
            <Select value={selectedHazardType} onValueChange={(v) => setSelectedHazardType(v as HazardType)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {hazardTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <div className="flex items-center gap-2">
                      <span className={type.color}>{type.icon}</span>
                      <span>{type.label}</span>
                      {type.value !== 'all' && (
                        <Badge variant="secondary" className="ml-auto text-xs">
                          {hazardCounts[type.value] || 0}
                        </Badge>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Severity Select */}
          <div className="space-y-2">
            <Label className="text-xs">Severity Level</Label>
            <Select value={selectedSeverity} onValueChange={(v) => setSelectedSeverity(v as SeverityLevel)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {severityLevels.map((level) => (
                  <SelectItem key={level.value} value={level.value}>
                    <span className={level.color}>{level.label}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* GIS Layers */}
      <Card className="border-0 bg-card/50 backdrop-blur">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Layers className="w-4 h-4" />
            GIS Layers
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Route className="w-4 h-4 text-blue-400" />
              <Label className="text-sm cursor-pointer" htmlFor="rivers">
                River Systems
              </Label>
            </div>
            <Switch
              id="rivers"
              checked={showRivers}
              onCheckedChange={setShowRivers}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-red-400" />
              <Label className="text-sm cursor-pointer" htmlFor="faults">
                Fault Lines
              </Label>
            </div>
            <Switch
              id="faults"
              checked={showFaultLines}
              onCheckedChange={setShowFaultLines}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-400" />
              <Label className="text-sm cursor-pointer" htmlFor="cities">
                Major Cities
              </Label>
            </div>
            <Switch
              id="cities"
              checked={showCities}
              onCheckedChange={setShowCities}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Car className="w-4 h-4 text-green-400" />
              <Label className="text-sm cursor-pointer" htmlFor="traffic">
                Live Traffic
              </Label>
            </div>
            <Switch
              id="traffic"
              checked={showTraffic}
              onCheckedChange={setShowTraffic}
            />
          </div>
        </CardContent>
      </Card>

      {/* Legend */}
      <Card className="border-0 bg-card/50 backdrop-blur">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Severity Legend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {severityLevels.slice(1).map((level) => (
              <div key={level.value} className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{
                    backgroundColor:
                      level.value === 'low'
                        ? '#22c55e'
                        : level.value === 'moderate'
                        ? '#eab308'
                        : level.value === 'high'
                        ? '#f97316'
                        : level.value === 'severe'
                        ? '#ef4444'
                        : '#a855f7',
                  }}
                />
                <span className={`text-xs ${level.color}`}>{level.label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
