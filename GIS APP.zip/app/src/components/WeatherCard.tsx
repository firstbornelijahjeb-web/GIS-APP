import { Cloud, CloudRain, Sun, Wind, Droplets, Eye, Gauge, Thermometer, CloudLightning, CloudFog } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { WeatherData } from '@/types';

interface WeatherCardProps {
  weather: WeatherData;
  compact?: boolean;
}

const weatherIcons: Record<string, React.ReactNode> = {
  'Sunny': <Sun className="w-12 h-12 text-yellow-400" />,
  'Clear': <Sun className="w-12 h-12 text-yellow-400" />,
  'Cloudy': <Cloud className="w-12 h-12 text-gray-400" />,
  'Partly Cloudy': <Cloud className="w-12 h-12 text-gray-300" />,
  'Rainy': <CloudRain className="w-12 h-12 text-blue-400" />,
  'Rain': <CloudRain className="w-12 h-12 text-blue-400" />,
  'Storm': <CloudLightning className="w-12 h-12 text-purple-400" />,
  'Thunderstorm': <CloudLightning className="w-12 h-12 text-purple-400" />,
  'Foggy': <CloudFog className="w-12 h-12 text-gray-400" />,
};

const getWeatherGradient = (condition: string): string => {
  const gradients: Record<string, string> = {
    'Sunny': 'from-orange-500/20 to-yellow-500/20',
    'Clear': 'from-orange-500/20 to-yellow-500/20',
    'Cloudy': 'from-gray-500/20 to-slate-500/20',
    'Partly Cloudy': 'from-gray-400/20 to-slate-400/20',
    'Rainy': 'from-blue-500/20 to-cyan-500/20',
    'Rain': 'from-blue-500/20 to-cyan-500/20',
    'Storm': 'from-purple-500/20 to-indigo-500/20',
    'Thunderstorm': 'from-purple-500/20 to-indigo-500/20',
    'Foggy': 'from-gray-500/20 to-zinc-500/20',
  };
  return gradients[condition] || 'from-primary/20 to-secondary/20';
};

export function WeatherCard({ weather, compact = false }: WeatherCardProps) {
  if (compact) {
    return (
      <Card className={`bg-gradient-to-br ${getWeatherGradient(weather.condition)} border-0`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{weather.location}</p>
              <p className="text-2xl font-bold">{weather.temperature}°C</p>
              <p className="text-xs text-muted-foreground">{weather.condition}</p>
            </div>
            <div className="scale-75">
              {weatherIcons[weather.condition] || <Cloud className="w-8 h-8" />}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`bg-gradient-to-br ${getWeatherGradient(weather.condition)} border-0 overflow-hidden`}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <span>{weather.location}</span>
          {weatherIcons[weather.condition] || <Cloud className="w-8 h-8" />}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-5xl font-bold">{weather.temperature}°</span>
          <span className="text-xl text-muted-foreground">C</span>
        </div>
        
        <p className="text-muted-foreground mb-4">{weather.description}</p>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">Feels like {weather.feelsLike}°C</span>
          </div>
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">{weather.humidity}% humidity</span>
          </div>
          <div className="flex items-center gap-2">
            <Wind className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">{weather.windSpeed} km/h</span>
          </div>
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">{weather.pressure} hPa</span>
          </div>
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">{weather.visibility} km visibility</span>
          </div>
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">UV Index {weather.uvIndex}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
