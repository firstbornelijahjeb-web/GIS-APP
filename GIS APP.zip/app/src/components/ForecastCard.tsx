import { Cloud, CloudRain, Sun, CloudLightning, CloudFog } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { ForecastData } from '@/types';

interface ForecastCardProps {
  forecast: ForecastData[];
}

const forecastIcons: Record<string, React.ReactNode> = {
  'Sunny': <Sun className="w-6 h-6 text-yellow-400" />,
  'Clear': <Sun className="w-6 h-6 text-yellow-400" />,
  'Cloudy': <Cloud className="w-6 h-6 text-gray-400" />,
  'Partly Cloudy': <Cloud className="w-6 h-6 text-gray-300" />,
  'Rainy': <CloudRain className="w-6 h-6 text-blue-400" />,
  'Rain': <CloudRain className="w-6 h-6 text-blue-400" />,
  'Storm': <CloudLightning className="w-6 h-6 text-purple-400" />,
  'Thunderstorm': <CloudLightning className="w-6 h-6 text-purple-400" />,
  'Foggy': <CloudFog className="w-6 h-6 text-gray-400" />,
};

export function ForecastCard({ forecast }: ForecastCardProps) {
  return (
    <Card className="border-0 bg-card/50 backdrop-blur">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">7-Day Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {forecast.map((day, index) => (
            <div
              key={day.date}
              className={`flex items-center justify-between p-3 rounded-lg ${
                index === 0 ? 'bg-primary/10' : 'bg-secondary/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium w-20">{day.date}</span>
                {forecastIcons[day.condition] || <Cloud className="w-6 h-6" />}
                <span className="text-sm text-muted-foreground">{day.condition}</span>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <CloudRain className="w-4 h-4 text-blue-400" />
                  <span className="text-xs">{day.precipitation}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{day.tempHigh}°</span>
                  <span className="text-sm text-muted-foreground">{day.tempLow}°</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
