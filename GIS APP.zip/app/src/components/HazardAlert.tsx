import { AlertTriangle, Droplets, Mountain, Wind, Waves, CloudRain, Thermometer, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { WeatherAlert, HazardZone } from '@/types';

interface HazardAlertProps {
  alert: WeatherAlert;
  onDismiss?: () => void;
}

const severityConfig = {
  low: { color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  moderate: { color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' },
  high: { color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  severe: { color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  extreme: { color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
};

const alertTypeIcons: Record<string, React.ReactNode> = {
  rainfall: <CloudRain className="w-5 h-5" />,
  thunderstorm: <Wind className="w-5 h-5" />,
  heat: <Thermometer className="w-5 h-5" />,
  flood: <Droplets className="w-5 h-5" />,
  earthquake: <Mountain className="w-5 h-5" />,
  tsunami: <Waves className="w-5 h-5" />,
  storm: <Wind className="w-5 h-5" />,
};

export function HazardAlertCard({ alert, onDismiss }: HazardAlertProps) {
  const severity = severityConfig[alert.severity];

  return (
    <Card className={`border ${severity.color} bg-card/50 backdrop-blur`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            {alertTypeIcons[alert.type] || <AlertTriangle className="w-5 h-5" />}
            <CardTitle className="text-base">{alert.title}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={severity.color}>
              {alert.severity.toUpperCase()}
            </Badge>
            {onDismiss && (
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onDismiss}>
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{alert.description}</p>
        
        <div className="flex flex-wrap gap-1">
          {alert.areas.map((area) => (
            <Badge key={area} variant="secondary" className="text-xs">
              {area}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Effective: {new Date(alert.effective).toLocaleString()}</span>
          <span>Expires: {new Date(alert.expires).toLocaleString()}</span>
        </div>

        <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
          <p className="text-sm font-medium text-destructive mb-1">Instruction:</p>
          <p className="text-sm text-destructive/80">{alert.instruction}</p>
        </div>
      </CardContent>
    </Card>
  );
}

interface HazardZoneCardProps {
  zone: HazardZone;
  onClick?: () => void;
}

const hazardTypeIcons: Record<string, React.ReactNode> = {
  flood: <Droplets className="w-5 h-5 text-blue-400" />,
  earthquake: <Mountain className="w-5 h-5 text-red-400" />,
  storm: <Wind className="w-5 h-5 text-purple-400" />,
  landslide: <Mountain className="w-5 h-5 text-amber-400" />,
  tsunami: <Waves className="w-5 h-5 text-cyan-400" />,
};

const severityColors = {
  low: 'bg-green-500/20 text-green-400 border-green-500/30',
  moderate: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  high: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  severe: 'bg-red-500/20 text-red-400 border-red-500/30',
  extreme: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
};

export function HazardZoneCard({ zone, onClick }: HazardZoneCardProps) {
  return (
    <Card 
      className="cursor-pointer hover:bg-accent/50 transition-colors border-0 bg-card/50 backdrop-blur"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="mt-1">{hazardTypeIcons[zone.type]}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-medium truncate">{zone.name}</h4>
              <Badge variant="outline" className={`text-xs ${severityColors[zone.severity]}`}>
                {zone.severity}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
              {zone.description}
            </p>
            <div className="flex flex-wrap gap-1 mt-2">
              {zone.affectedAreas.slice(0, 3).map((area) => (
                <span key={area} className="text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded">
                  {area}
                </span>
              ))}
              {zone.affectedAreas.length > 3 && (
                <span className="text-xs text-muted-foreground">
                  +{zone.affectedAreas.length - 3} more
                </span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
